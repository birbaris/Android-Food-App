package com.example.bitirmeprojesi.data.repo;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.example.bitirmeprojesi.data.entity.Basket;
import com.example.bitirmeprojesi.data.entity.BasketResponse;
import com.example.bitirmeprojesi.data.entity.FoodsList;
import com.example.bitirmeprojesi.retrofit.FoodDao;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FoodDaoRepository {
    private MutableLiveData<List<FoodsList>> yemeklerList;
    private MutableLiveData<List<Basket>> sepettekiYemeklerList = null;
    private FoodDao ydao;
    public FoodDaoRepository(FoodDao ydao) {
        this.ydao = ydao;
        yemeklerList = new MutableLiveData();
        sepettekiYemeklerList = new MutableLiveData();
    }
    public MutableLiveData<List<FoodList>> getYemeklerList() {
        return yemeklerList;
    }
    public MutableLiveData<List<Basket>> getSepettekiYemeklerList() {
        return sepettekiYemeklerList;
    }
    public void ara(String aramaKelimesi){
        kdao.ara(aramaKelimesi).enqueue(new Callback<KisilerCevap>() {
            @Override
            public void onResponse(Call<KisilerCevap> call, Response<KisilerCevap> response) {
                List<Kisiler> liste = response.body().getKisiler();
                kisilerListesi.setValue(liste);
            }

            @Override
            public void onFailure(Call<KisilerCevap> call, Throwable t) {

            }
        });
    }

    public void sil(int kisi_id){
        kdao.sil(kisi_id).enqueue(new Callback<CRUDCevap>() {
            @Override
            public void onResponse(Call<CRUDCevap> call, Response<CRUDCevap> response) {
                kisileriYukle();

            }

            @Override
            public void onFailure(Call<CRUDCevap> call, Throwable t) {}
        });
    }
}

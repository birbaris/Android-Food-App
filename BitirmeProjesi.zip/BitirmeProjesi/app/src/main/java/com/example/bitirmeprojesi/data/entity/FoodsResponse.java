package com.example.bitirmeprojesi.data.entity;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FoodsResponse {
    @SerializedName("yemekler")
    private List<FoodsList> yemekler;
    @SerializedName("success")
    private int success;

    public FoodsResponse() {
    }

    public FoodsResponse(List<FoodsList> yemekler, int success) {
        this.yemekler = yemekler;
        this.success = success;
    }

    public List<FoodsList> getyemekler() {
        return yemekler;
    }

    public void setyemekler(List<FoodsList> yemekler) {
        this.yemekler = yemekler;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }
}
}

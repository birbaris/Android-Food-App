package com.example.bitirmeprojesi.di;


import com.example.bitirmeprojesi.data.repo.FoodDaoRepository;
import com.example.bitirmeprojesi.retrofit.ApiUtils;
import com.example.bitirmeprojesi.retrofit.FoodDao;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class AppModule {
    @Provides
    @Singleton
    public FoodDaoRepository provideFoodDaoRepository(FoodDao fdao){
        return new FoodDaoRepository(fdao);
    }
    @Provides
    @Singleton
    public FoodDao provideFoodDao() { return ApiUtils.getFoodDao(); }

}


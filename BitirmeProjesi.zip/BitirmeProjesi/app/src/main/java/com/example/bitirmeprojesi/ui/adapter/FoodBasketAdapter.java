package com.example.bitirmeprojesi.ui.adapter;

public class FoodBasketAdapter {
}

package com.example.bitirmeprojesi.data.entity;

import com.google.gson.annotations.SerializedName;

public class FoodsList {
    @SerializedName("yemek_id")
    private int yemek_id;
    @SerializedName("yemek_adi")
    private String yemek_adi;
    @SerializedName("yemek_resim_adi")
    private String yemek_resim_adi;
    @SerializedName("yemek_fiyat")
    private int  yemek_fiyat;

    public FoodsList() {
    }

    public FoodsList(int yemek_id, String yemek_adi, String yemek_resim_adi, int yemek_fiyat) {
        this.yemek_id = yemek_id;
        this.yemek_adi = yemek_adi;
        this.yemek_resim_adi = yemek_resim_adi;
        this.yemek_fiyat = yemek_fiyat;
    }

    public int getyemek_id() {
        return yemek_id;
    }

    public void setyemek_id(int yemek_id) {
        this.yemek_id = yemek_id;
    }

    public String getyemek_adi() {
        return yemek_adi;
    }

    public void setyemek_adi(String yemek_adi) {
        this.yemek_adi = yemek_adi;
    }

    public String getyemek_resim_adi() {
        return yemek_resim_adi;
    }

    public void setyemek_resim_adi(String yemek_resim_adi) {
        this.yemek_resim_adi = yemek_resim_adi;
    }

    public int getyemek_fiyat() {
        return yemek_fiyat;
    }

    public void setyemek_fiyat(int yemek_fiyat) {
        this.yemek_fiyat = yemek_fiyat;
    }
}
}

package com.example.bitirmeprojesi.ui.viewmodel;

public class MainViewModel {
}

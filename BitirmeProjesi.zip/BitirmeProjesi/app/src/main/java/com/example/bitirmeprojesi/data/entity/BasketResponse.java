package com.example.bitirmeprojesi.data.entity;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BasketResponse {
    @SerializedName("sepet_yemekler")
    private List<Basket> sepet_yemekler;
    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public BasketViewModel() {
    }

    public BasketResponse(List<Basket> sepet_yemekler, int success, String message) {
        this.sepet_yemekler = sepet_yemekler;
        this.success = success;
        this.message = message;
    }

    public List<Basket> getsepet_yemekler() {
        return sepet_yemekler;
    }

    public void setsepet_yemekler(List<Basket> sepet_yemekler) {
        this.sepet_yemekler = sepet_yemekler;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

}
